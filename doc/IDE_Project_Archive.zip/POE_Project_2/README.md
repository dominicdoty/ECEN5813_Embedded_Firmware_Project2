# ECEN5813 Embedded Firmware Project 2
Basic program for FRDM-KL25Z development board
Program accepts input over UART, categorizes the input and then displays the count of each 
char it has received.
